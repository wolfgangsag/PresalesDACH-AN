## Meeting Agenda:
#### Tues, May 11 2021, 8:00 a.m PST / 11:00 a.m EST 

- TSC Member Introductions - All
- OMP COBOL Programming Course Update - Sudharsana
- OMP COBOL Check Presentation & Demo - Dave Nicolette
- Q&A

## Meeting Minutes:
Attendees: Mike, Paul, Jelly & few community participants

1. Core Team members introductions
2. Sudharsana shared some exciting news about the project
   - COBOL Programming Course project is now an 'Active Stage Project'
   - COBOL Programming Course has 2 summer mentees. 
   - Summer mentees will start working on the project in June
3. Mike shared with the community release update
   - A new pdf release will happen at the end of the summer mentorship project
4. Dave Nicolette from the cobol-check program gave a demo of the tool
   - Please watch the replay of the session for more details.

##### Q. Where can I find TSC meeting replay recordings?
   - Replays can be found in the OMP COBOL Google folder [here](https://drive.google.com/drive/folders/1z0Xlh6mJ0QoPh0S_F1Dpt1O4rHL1Ckg8)

## Next Meeting:
#### Tues, Aug 10 2021, 8:00 a.m PST / 11:00 a.m EST 

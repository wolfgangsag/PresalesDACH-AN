## Meeting Agenda:
### Tues, Sept 8th 8:00 a.m PST / 11:00 a.m EST 

- TSC Members Introductions - All
- Project Update - Sudharsana & Mike
- Db2 Project Update - Paul
- Q&A

## Meeting Minutes:
Attendees: All Core team members & few community participants

1. Core Team members introduced themselves
2. Sudharsana shared a quick update on COBOL Course 
   - requested community participation in building up content for Course #2
3. Paul shared an update on the Db2 labs
   - Raven was on the call and shared the work she has been doing with Paul
4. Q&A
   - No questions on this call. It was a fairly short call

#### Next Meeting
Tues, Oct 13th 8 a.m PST / 11 a.m EST

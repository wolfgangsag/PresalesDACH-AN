## Meeting Agenda:
### Wed, Nov 18th 8:00 a.m PST / 11:00 a.m EST 

- TSC Member Introductions - All
- Project Update & PDF Releases - Mike
- Master the Mainframe 2020 - COBOL Challenges - Jeff Bisti
- Q&A

## Meeting Minutes:
Attendees: All Core team members & few community participants

1. Core Team members introduced themselves
2. Mike shared a quick update on COBOL Course 
   - requested community participation in building up content for Course #2
   - shared the content in v2.2.0 of the COBOL Course PDF
3. Jeff Bisti reviewed the Master the Mainframe contest particularly sharing the COBOL challenges woven into this year's contest - check out a recording [here](https://drive.google.com/drive/folders/1z0Xlh6mJ0QoPh0S_F1Dpt1O4rHL1Ckg8)!
4. Q&A/Open discussion
   - Hartanto (a community member) shared he would like to take a few issues and implement them into the course content. Thank you Hartanto!

#### Next Meeting
Happy Holidays! See you all in January 2021.

# Translation
These translations are provided by community members for the benefit of the community. Neither this project nor Open Mainframe Project reviews, maintains, or endorses any one of these particular providers. 

If you are interested in contributing translations of the course into this project, feel free to [edit and issue a pull request](https://github.com/openmainframeproject/cobol-programming-course/edit/master/TRANSLATION.md) to have it included. As a guideline, translations contributed to this list should be a full translation of the corresponding course.

## Course #1 - Getting Started
| Version | Language | Author |
|:-------:|:--------:|:------:|
| [2.3](https://github.com/openmainframeproject/cobol-programming-course/releases/download/2.3.0/COBOL-Programming-Course-1-Getting-Started-French.pdf) | French | Bernard Zisermann |

## Course #2 - Advanced Topics
| Version | Language | Author |
|:-------:|:--------:|:------:|
| | | |

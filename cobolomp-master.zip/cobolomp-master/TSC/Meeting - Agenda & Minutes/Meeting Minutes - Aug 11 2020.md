## Meeting Agenda:
### Tues, Aug 11th 8:00 a.m PST / 11:00 a.m EST 

- TSC Members Introductions - All
- Project Update - Sudharsana
- System Disk Storage guidelines - Paul
- ZOWE Update - Mike
- COBOL Working Group Update - Dr. Cameron Saey
- Q&A

## Meeting Minutes:
Attendees: All Core team members & few community participants

1. Core Team members introduced themselves
2. Sudharsana shared a quick update on COBOL Course 
   - requested for community help with getting content added to Course #2
3. Paul shared that he is working on Disk Storage guidelines and will share soon
   - Request to be mindful when allocating system resources
4. Mike gave an overview on ZOWE, a sister project on OMP 
5. Dr. Cameron Saey shared about the new initiative called COBOL Working group. This latest initiative on OMP is looking to bring academic attention to COBOL.
5. Q&A - No questions 

#### Next Meeting
Tues, Sept 8th 8 a.m PST / 11 a.m EST
